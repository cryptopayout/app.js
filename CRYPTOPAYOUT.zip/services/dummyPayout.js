function process(wallet, amount) {
  return {
    status: 'success',
    message: `INR payout simulated for wallet ${wallet} with amount ${amount}`
  };
}

module.exports = { process };