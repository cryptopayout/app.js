const express = require('express');
const router = express.Router();
const payoutService = require('../services/dummyPayout');

router.post('/', (req, res) => {
  const { wallet, amount } = req.body;
  const result = payoutService.process(wallet, amount);
  res.json(result);
});

module.exports = router;